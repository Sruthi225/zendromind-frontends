import React from "react";

export default function FooterLayout() {
    return (
        <footer className="mc-footer">© All Rights Reserved by ♥ Mironcoder</footer>
    )
}