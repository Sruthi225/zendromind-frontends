import React from "react";
import JoditEditor from "jodit-react";

export default function RichTextEditorComponent() {

	return (
		<JoditEditor />
	)
}