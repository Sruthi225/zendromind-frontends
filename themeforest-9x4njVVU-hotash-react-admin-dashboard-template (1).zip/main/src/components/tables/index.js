export { default as ProductsTableComponent } from "./ProductsTableComponent";
export { default as ClientsTableComponent } from "./ClientsTableComponent";
export { default as TrafficsTableComponent } from "./TrafficsTableComponent";
export { default as InvoiceTableComponent } from "./InvoiceTableComponent";
export { default as OrdersTableComponent } from "./OrdersTableComponent";
export { default as UsersTableComponent } from "./UsersTableComponent";
export { default as PagesTableComponent } from "./PagesTableComponent";
export { default as DealsTableComponent } from "./DealsTableComponent";
